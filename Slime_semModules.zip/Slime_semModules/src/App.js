import React, { useRef, useEffect, useState } from 'react';
import './App.css';
import MenuView from './components/MenuView';
import GameCanvas from './components/GameCanvas';
// load all extracted slime frames (if present)
let slimeSprites = [];
try {
  const ctx = require.context('./assets/img', false, /\.png$/);
  slimeSprites = ctx.keys().map(k => ctx(k));
} catch (e) {
  slimeSprites = [];
}

function App() {
  const [mode, setMode] = useState('menu'); // 'menu' | 'play' | 'highscore'
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [selectedAvatar, setSelectedAvatar] = useState(1);

  function addScore(n) { setScore(s => s + n); }
  function resetScore() { setScore(0); }

  // level configuration and level initialization moved into `GameCanvas` component.

  // start playing (called from menu)
  function startGame() { resetScore(); setMode('play'); }

  // canvas and game loop moved to `GameCanvas` component

  // back to menu handler passed to GameCanvas
  function backToMenu() { setMode('menu'); }

  return (
    <div className="App game-root">
      <header className="App-header game-header">
        {mode === 'menu' && (
          <MenuView onStart={startGame} onHighscore={() => setMode('highscore')} sprites={slimeSprites} selectedAvatar={selectedAvatar} setSelectedAvatar={setSelectedAvatar} />
        )}

        {mode === 'highscore' && (
          <div className="menu">
            <h2>High Scores</h2>
            <p>(Not implemented) — place-holder screen.</p>
            <div className="menu-buttons">
              <button onClick={() => setMode('menu')}>Back</button>
            </div>
          </div>
        )}

        {mode === 'play' && (
          <>
            <div className="game-top">
              <div className="title">Ultra Slime Mega Wars</div>
            </div>
            <GameCanvas slimeSprites={slimeSprites} selectedAvatar={selectedAvatar} onBack={backToMenu} onScoreAdd={addScore} onLevelChange={setLevel} />
          </>
        )}
      </header>
    </div>
  );
}

export default App;
